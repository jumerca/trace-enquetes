# Animopolis — sources

Le jeu publié (`../animopolis/index.html`) est **généré** à partir des fichiers de ce dossier.
Ne modifie pas `index.html` à la main : modifie les sources puis relance le script de construction.

## Construire

```bash
./build.sh                      # build daté de maintenant, écrit dans ../animopolis/
VERSION=2.2 ./build.sh          # change aussi le numéro de version (sinon : fichier VERSION)
BUILD=202611120921 OUT=/tmp/x ./build.sh   # build reproductible vers un autre dossier
```

Le script écrit trois fichiers dans `../animopolis/` :
- `index.html` : `head.html` + `parts/*.js` (dans l'ordre des numéros) + `tail.html`, avec `APP_VERSION` et `APP_BUILD` remplacés ;
- `sw.js` : `sw.tpl.js` daté avec le numéro de build (change à chaque build, ce qui renouvelle le cache de l'application installée) ;
- `version.json` : lu par le jeu pour savoir si une version plus récente existe.

**À chaque modification publiée, relance `build.sh`** : un nouveau numéro de build est ce qui déclenche la mise à jour sur les téléphones et affiche la bonne version sur la page d'accueil. Puis fusionne dans `main` : GitHub Pages publie le dossier `animopolis/`.

## Les morceaux (`parts/`, concaténés dans cet ordre)

| Fichier | Contenu |
|---|---|
| `00-base.js` | constantes, couleurs, générateur aléatoire déterministe, primitives de dessin |
| `01-chars.js` | têtes d'animaux, chapeaux, objets tenus, poses, silhouettes, queues, `drawChar` |
| `02-world.js` | moteur isométrique (projection, tri en profondeur), décor commun, bâtiments, foule |
| `03-city.js` | décors de fête foraine, quartiers Le Centre et Le Port, enquêtes de départ |
| `04-city2.js` | quartier La Gare, enquête Zorbo et ses scènes |
| `05-city3.js` | quartier La Colline (forêt, village, château) |
| `06-urban.js` | canal, ponts, rond-point, rue en biais, oiseaux |
| `07-ombre.js` | fil rouge de l'Ombre : indices et enquête finale |
| `08-more.js` | enquêtes supplémentaires (vase, chapeau, phare, pêche, tickets…) |
| `09-island.js` | quartier L'Île aux Tortues |
| `09b-variety.js` | étapes variées (plusieurs objets, compter, intrus, déduction) et l'enquête « Le jeu de piste de Bobo » |
| `09d-newcases.js` | « Sabotage au feu d'artifice » (Fête foraine) et la finale « Les œufs d'or de la Grande Tortue » (île, champ `req` = enquêtes à classer d'abord) ; corps salopette/robe/poncho/tutu sur les personnages nommés |
| `10b-actors.js` | voitures qui roulent et passants qui marchent, dessinés à chaque image par-dessus les tuiles |
| `10-decoys.js` | questions énigmatiques des enquêtes difficiles et sosies des suspects |
| `11-ui.js` | rendu par tuiles, caméra, gestes, cartes d'enquête, dossiers, étoiles, carnet, défi chrono |
| `12-home.js` | accueil, parties sauvegardées, options, installation, version et mises à jour |
| `13-audio.js` | sons, musique et ambiance synthétisés avec WebAudio (aucun fichier), branchés sur le jeu |
| `14-fx.js` | confettis de fin d'enquête |

Autres fichiers : `head.html` (balises, styles, structure de la page), `tail.html` (fermeture), `sw.tpl.js` (service worker), `VERSION`.

## Types d'étapes

| Type | Comment le déclarer | Exemple |
|---|---|---|
| **Trouver une scène** | `{q, ok, w}` puis `setT(cas, n, u, v, rayon)` | la plupart des étapes |
| **Choisir un portrait** (« qui est le coupable ? », déduction) | `{q, ok, choice:[CH('nom', personnage), …], ans}` ; mets les témoignages dans `q` (HTML autorisé) | `vase`, `phare`, `tresor`, `bobo` |
| **Compter / réponse en texte** | `choice:[CH('3'), CH('4'), …]` (sans personnage) ; avec `t`, un bouton « Voir la scène » apparaît | `gateau`, `ballon`, `lettre` |
| **Trouver plusieurs objets** | `stepMulti(étape, [[u,v], …], rayon)` : chaque objet touché est compté (« 2/3 trouvés ») | `chaton`, `tickets`, `chiot`, `farine`, `bobo` |
| **Trouver l'intrus** | `oddGroup(u, v, n, communs, intrus, têtesExclues, écart)` dessine un groupe presque identique ; puis `stepAt(étape, ...intrus)` | `poisson`, `fantome`, `bobo` |

Les étapes ajoutées après coup se déclarent dans `parts/09b-variety.js` (`insertAfter(cas, étapeDeRéférence, étape)`), après la construction des scènes, pour ne pas décaler les numéros d'étapes déjà utilisés par `setT`.

**Sauvegardes** : quand une enquête gagne ou perd des étapes, `migrate()` (dans `11-ui.js`) adapte les parties déjà enregistrées : une enquête classée le reste, une enquête commencée repart de zéro. Si tu changes le nombre d'étapes d'une enquête, rien d'autre à faire : le nombre est mémorisé dans chaque sauvegarde (`caseLen`).

## Personnages et animations

- **Silhouettes** : `build` (`normal`, `round`, `slim`, `tall`, `small`, `old`), **tenues** (`body` : `coat`, `suit`, `shirt`, `dress`, `chef`, `robe`, `overalls`, `poncho`, `tutu`, `puffer`) et **espèces** (`HEADS` + `NEWHEADS` : girafe, tortue, mouton, hippopotame). La foule en tire au hasard avec un générateur à part, pour ne pas bouger le reste de la ville.
- **Éléments animés** : `addMover(zone, dessin, empreinteAuSol)` pour une partie qui bouge sur place (fumée, roue, gouttes d'eau) ; `10b-actors.js` pour ce qui se déplace (voitures, passants). Ils sont redessinés à chaque image, puis les éléments qui sont devant eux sont redessinés par-dessus.
- **Sons** : tout est synthétisé dans `13-audio.js`. `SFX` (effets), `THEMES` (un thème de musique par quartier), ambiance selon le quartier au centre de l'écran. Réglages dans Options et bouton 🔊 en haut.

## Ajouter une enquête

1. Ajoute l'objet dans `CASES.push({...})` (`id`, `dist` = numéro de quartier, `diff` 1 à 3, `intro`, `cast`, `steps`, `outro`).
2. Pour chaque étape, appelle `setT('id', numéro_étape, u, v, rayon)` à l'endroit où tu poses la scène (ou `setTxy` en coordonnées écran). Une étape « qui est le coupable ? » a `choice` et `ans` au lieu d'une cible.
3. Place les personnages avec `addChar(u, v, personnage, {…})`.
4. Reconstruis, puis lance le test ci-dessous.

## Tester

```bash
npm i playwright                # une fois, hors dépôt
node tests/playthrough.js       # rejoue toutes les enquêtes de zéro à la fin
node tests/audio.js             # rend les effets et les thèmes de musique hors ligne : ni muets, ni saturés
```

Le test résout toutes les étapes dans l'ordre d'ouverture et vérifie que les 6 quartiers s'ouvrent, que les 5 indices de l'Ombre sont réunis et que l'enquête finale se termine, sans erreur. On peut aussi le lancer sur le site publié : `ANIMOPOLIS_URL=https://jumerca.github.io/trace-enquetes/animopolis/ node tests/playthrough.js`.
